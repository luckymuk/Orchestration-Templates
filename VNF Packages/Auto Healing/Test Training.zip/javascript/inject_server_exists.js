$.stack_params.cbam.resources.trainingServerWithVolume[0].trainingServer.exists = 1
return $.stack_params